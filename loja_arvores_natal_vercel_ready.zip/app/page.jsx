
export default function Home() {
  return (
    <main style={{padding:20, fontFamily:'sans-serif'}}>
      <h1>Loja de Árvores de Natal</h1>
      <p>Promoções especiais com frete grátis!</p>
      <img src="/images/bannerNatal.png" width="100%" />
      <button onClick={()=>{
        fetch('/api/create-checkout-session',{method:'POST'})
          .then(res=>res.json())
          .then(d=>window.location = d.url)
      }}
      style={{padding:14, background:'green', color:'white', marginTop:20, fontSize:18}}>
        Comprar Agora
      </button>
    </main>
  )
}
