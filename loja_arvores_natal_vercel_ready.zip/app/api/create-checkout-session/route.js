
import Stripe from 'stripe';
export async function POST() {
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
  const session = await stripe.checkout.sessions.create({
    mode: 'payment',
    success_url: 'https://loja-arvores-natal.vercel.app/sucesso',
    cancel_url: 'https://loja-arvores-natal.vercel.app',
    line_items:[
      { price_data:{currency:'brl', product_data:{name:'Árvore de Natal Premium'}, unit_amount:19900}, quantity:1 }
    ]
  })
  return Response.json({url: session.url})
}
